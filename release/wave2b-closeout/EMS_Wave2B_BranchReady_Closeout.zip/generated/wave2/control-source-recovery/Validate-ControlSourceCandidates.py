import sys, re, json, yaml
from pathlib import Path

def walk(x, ids, named):
    if isinstance(x, dict):
        cid=x.get("control_id") or x.get("id")
        if isinstance(cid,str) and re.fullmatch(r"EMS-CTRL-\d{3}",cid):
            ids.add(cid)
            name=x.get("control_name") or x.get("name") or x.get("title")
            if isinstance(name,str) and name.strip():
                named.add(cid)
        for v in x.values():
            walk(v,ids,named)
    elif isinstance(x,list):
        for v in x:
            walk(v,ids,named)

results=[]
for raw in sys.argv[1:]:
    p=Path(raw)
    ids=set(); named=set()
    try:
        d=yaml.safe_load(p.read_text(encoding="utf-8"))
        walk(d,ids,named)
        results.append({
            "path":str(p),
            "control_id_count":len(ids),
            "named_control_count":len(named),
            "has_all_80":len(ids)==80,
            "missing":[f"EMS-CTRL-{i:03d}" for i in range(1,81) if f"EMS-CTRL-{i:03d}" not in ids]
        })
    except Exception as e:
        results.append({"path":str(p),"error":str(e),"control_id_count":0,"named_control_count":0,"has_all_80":False})

print(json.dumps(results,indent=2))
